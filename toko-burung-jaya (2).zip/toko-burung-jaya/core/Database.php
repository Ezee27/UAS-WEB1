<?php
class Database {
    protected $conn;

    public function __construct() {
        // Membuat koneksi ke database
        $this->conn = new mysqli("localhost", "root", "", "toko_burung_jaya");

        // Cek koneksi database
        if ($this->conn->connect_error) {
            die("Koneksi database gagal: " . $this->conn->connect_error);
        }
    }

    // Fungsi untuk menjalankan query biasa
    public function query($sql) {
        return $this->conn->query($sql);
    }

    // Fungsi untuk escape data (menghindari SQL Injection)
    public function escape($data) {
        return $this->conn->real_escape_string($data);
    }

    // Fungsi untuk menyiapkan query (prepared statement)
    public function prepare($sql) {
        return $this->conn->prepare($sql);
    }

    // Fungsi untuk menutup koneksi
    public function close() {
        $this->conn->close();
    }
}
