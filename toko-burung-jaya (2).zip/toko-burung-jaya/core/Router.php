<?php

$url = $_GET['url'] ?? '';

// ===============================
// DEFAULT ROUTE
// ===============================
if ($url === '') {
    if (isset($_SESSION['user'])) {
        $role = $_SESSION['user']['role'];
        header("Location: " . BASE_URL . "/$role/dashboard");
    } else {
        header("Location: " . BASE_URL . "/auth");
    }
    exit;
}

// ===============================
// PARSE URL
// ===============================
$url = rtrim($url, '/');
$url = explode('/', $url);

$controllerName = ucfirst($url[0]) . 'Controller';
$method         = $url[1] ?? 'index';
$param          = $url[2] ?? null;

$controllerPath = __DIR__ . '/../app/controllers/' . $controllerName . '.php';

// ===============================
// VALIDASI CONTROLLER
// ===============================
if (!file_exists($controllerPath)) {
    die("Controller tidak ditemukan");
}

require_once $controllerPath;

$controller = new $controllerName;

// ===============================
// VALIDASI METHOD
// ===============================
if (!method_exists($controller, $method)) {
    die("Method tidak ditemukan");
}

// ===============================
// JALANKAN CONTROLLER
// ===============================
call_user_func_array(
    [$controller, $method],
    $param ? [$param] : []
);
