<?php require "../app/views/layout/header.php"; ?>

<h3>Tambah Burung</h3>

<form method="POST" enctype="multipart/form-data">
    <div class="mb-3">
        <label>Nama Burung</label>
        <input type="text" name="nama_burung" class="form-control" required>
    </div>

    <div class="mb-3">
        <label>Jenis</label>
        <input type="text" name="jenis" class="form-control" required>
    </div>

    <div class="mb-3">
        <label>Harga</label>
        <input type="number" name="harga" class="form-control" required>
    </div>

    <div class="mb-3">
        <label>Stok</label>
        <input type="number" name="stok" class="form-control" required>
    </div>

    <div class="mb-3">
        <label>Deskripsi</label>
        <textarea name="deskripsi" class="form-control" required></textarea>
    </div>

    <div class="mb-3">
        <label>Gambar Burung</label>
        <input type="file" name="gambar" class="form-control" accept="image/*" required>
    </div>

    <button class="btn btn-success">Tambah Burung</button>
</form>

<?php require "../app/views/layout/footer.php"; ?>
