<?php require "../app/views/layout/header.php"; ?>

<h3>Edit Burung</h3>

<form method="POST" enctype="multipart/form-data">

    <input type="hidden" name="gambar_lama" value="<?= $burung['gambar'] ?>">

    <div class="mb-3">
        <label>Nama Burung</label>
        <input type="text" name="nama_burung" class="form-control"
               value="<?= htmlspecialchars($burung['nama_burung']) ?>" required>
    </div>

    <div class="mb-3">
        <label>Jenis</label>
        <input type="text" name="jenis" class="form-control"
               value="<?= htmlspecialchars($burung['jenis']) ?>" required>
    </div>

    <div class="mb-3">
        <label>Harga</label>
        <input type="number" name="harga" class="form-control"
               value="<?= $burung['harga'] ?>" required>
    </div>

    <div class="mb-3">
        <label>Stok</label>
        <input type="number" name="stok" class="form-control"
               value="<?= $burung['stok'] ?>" required>
    </div>

    <div class="mb-3">
        <label>Deskripsi</label>
        <textarea name="deskripsi" class="form-control" required><?= htmlspecialchars($burung['deskripsi']) ?></textarea>
    </div>

    <?php if (!empty($burung['gambar'])): ?>
        <div class="mb-3">
            <label>Gambar Saat Ini</label><br>
            <img src="<?= BASE_URL ?>/public/uploads/burung/<?= htmlspecialchars($burung['gambar']) ?>"
                 width="150" class="rounded shadow">
        </div>
    <?php endif; ?>

    <div class="mb-3">
        <label>Ganti Gambar (opsional)</label>
        <input type="file" name="gambar" class="form-control" accept="image/*">
    </div>

    <button class="btn btn-warning">Update Burung</button>
</form>

<?php require "../app/views/layout/footer.php"; ?>
