<?php require "../app/views/layout/header.php"; ?>

<div class="container-fluid">

    <!-- HEADER -->
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h3 class="fw-bold text-dark">
            🐦 Manajemen Data Burung
        </h3>

        <a href="<?= BASE_URL ?>/burung/tambah" class="btn btn-success btn-lg shadow-sm">
            ➕ Tambah Burung
        </a>
    </div>

    <!-- SEARCH -->
    <div class="card shadow-sm border-0 mb-4">
        <div class="card-body">
            <input type="text"
                   id="searchInput"
                   class="form-control form-control-lg"
                   placeholder="🔍 Cari nama / jenis burung...">
        </div>
    </div>

    <!-- TABLE -->
    <div class="card shadow-sm border-0">
        <div class="card-body p-0">
            <div class="table-responsive">
                <table class="table table-hover align-middle mb-0">
                    <thead class="table-dark text-center">
                        <tr>
                            <th>No</th>
                            <th>Nama Burung</th>
                            <th>Jenis</th>
                            <th>Harga</th>
                            <th>Stok</th>
                            <th style="width:150px">Aksi</th>
                        </tr>
                    </thead>
                    <tbody id="burungTable">
                        <?php if (!empty($burung)): ?>
                            <?php foreach ($burung as $key => $b): ?>
                                <tr>
                                    <td class="text-center"><?= $key + 1 ?></td>

                                    <td class="fw-semibold">
                                        <?= htmlspecialchars($b['nama_burung']) ?>
                                    </td>

                                    <td>
                                        <span class="badge bg-info text-dark">
                                            <?= htmlspecialchars($b['jenis']) ?>
                                        </span>
                                    </td>

                                    <td class="fw-bold text-success">
                                        Rp <?= number_format($b['harga']) ?>
                                    </td>

                                    <td class="text-center">
                                        <?php if ($b['stok'] > 0): ?>
                                            <span class="badge bg-success">
                                                <?= $b['stok'] ?>
                                            </span>
                                        <?php else: ?>
                                            <span class="badge bg-danger">
                                                Habis
                                            </span>
                                        <?php endif; ?>
                                    </td>

                                    <td class="text-center">
                                        <a href="<?= BASE_URL ?>/burung/edit/<?= $b['id'] ?>"
                                           class="btn btn-warning btn-sm me-1">
                                            ✏️
                                        </a>

                                        <a href="<?= BASE_URL ?>/burung/hapus/<?= $b['id'] ?>"
                                           class="btn btn-danger btn-sm"
                                           onclick="return confirm('Yakin hapus burung ini?')">
                                            🗑️
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="6" class="text-center text-muted py-4">
                                    Data burung masih kosong
                                </td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

</div>

<!-- SEARCH SCRIPT -->
<script>
document.getElementById('searchInput').addEventListener('keyup', function () {
    const filter = this.value.toLowerCase();
    const rows = document.querySelectorAll('#burungTable tr');

    rows.forEach(row => {
        row.style.display = row.textContent.toLowerCase().includes(filter)
            ? ''
            : 'none';
    });
});
</script>

<?php require "../app/views/layout/footer.php"; ?>
