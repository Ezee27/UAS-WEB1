<?php require "../app/views/layout/header.php"; ?>

<h3 class="fw-bold mb-4 text-center">📊 Dashboard Admin</h3>

<!-- STAT CARDS -->
<div class="row g-4 mb-4 justify-content-center">

    <!-- Total Burung -->
    <div class="col-md-3">
        <div class="card shadow-lg border-0 rounded-3 p-4">
            <div class="card-body text-center">
                <h6 class="text-muted">Total Burung</h6>
                <h3 class="fw-bold text-success">🐦 <?= $totalBurung ?></h3>
                <a href="<?= BASE_URL ?>/burung"
                   class="btn btn-outline-success btn-lg px-4 py-2 rounded-pill mt-3">
                    Kelola Burung
                </a>
            </div>
        </div>
    </div>

    <!-- Total Pembelian -->
    <div class="col-md-3">
        <div class="card shadow-lg border-0 rounded-3 p-4">
            <div class="card-body text-center">
                <h6 class="text-muted">Total Pembelian</h6>
                <h3 class="fw-bold text-primary">
                    🛒 Rp <?= number_format($totalPembelian) ?>
                </h3>
                <a href="<?= BASE_URL ?>/admin/pembelian"
                   class="btn btn-outline-primary btn-lg px-4 py-2 rounded-pill mt-3">
                    Lihat Pembelian
                </a>
            </div>
        </div>
    </div>

    <!-- Pemesanan -->
    <div class="col-md-3">
        <div class="card shadow-lg border-0 rounded-3 p-4">
            <div class="card-body text-center">
                <h6 class="text-muted">Pemesanan</h6>
                <h3 class="fw-bold text-warning">📦 Pesanan</h3>
                <a href="<?= BASE_URL ?>/admin/pemesanan"
                   class="btn btn-outline-warning btn-lg px-4 py-2 rounded-pill mt-3">
                    Kelola Pesanan
                </a>
            </div>
        </div>
    </div>

    <!-- User Terdaftar -->
    <div class="col-md-3">
        <div class="card shadow-lg border-0 rounded-3 p-4">
            <div class="card-body text-center">
                <h6 class="text-muted">User Terdaftar</h6>
                <h3 class="fw-bold text-dark">👤 <?= $totalUser ?></h3>
                <a href="<?= BASE_URL ?>/admin/user"
                   class="btn btn-outline-secondary btn-lg px-4 py-2 rounded-pill mt-3">
                    Lihat User
                </a>
            </div>
        </div>
    </div>

</div>

<!-- STYLE -->
<style>
    body {
        background-color: #f8f9fa;
    }

    .card {
        transition: transform 0.3s ease-in-out, box-shadow 0.3s ease-in-out;
        border-radius: 18px;
    }

    .card:hover {
        transform: translateY(-6px);
        box-shadow: 0px 8px 20px rgba(0, 0, 0, 0.12);
    }

    .btn {
        transition: all 0.2s ease-in-out;
    }

    .btn:hover {
        transform: scale(1.03);
    }

    .row.g-4 {
        margin-top: 30px;
    }
</style>

<?php require "../app/views/layout/footer.php"; ?>
