<?php require "../app/views/layout/header.php"; ?>

<h3 class="fw-bold mb-4 text-center">📦 Manajemen Pemesanan</h3>

<div class="table-responsive">
    <table class="table table-bordered table-striped align-middle">
        <thead class="table-dark text-center">
            <tr>
                <th>User</th>
                <th>Burung</th>
                <th>Jumlah</th>
                <th>Total</th>
                <th>Alamat</th>
                <th>Status</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>

        <?php if (!empty($pesanan)): ?>
            <?php foreach ($pesanan as $p): ?>
                <tr>
                    <td><?= htmlspecialchars($p['username']) ?></td>
                    <td><?= htmlspecialchars($p['nama_burung']) ?></td>
                    <td class="text-center"><?= $p['jumlah'] ?></td>
                    <td>Rp <?= number_format($p['total']) ?></td>
                    <td><?= htmlspecialchars($p['alamat']) ?></td>

                    <!-- STATUS -->
                    <td class="text-center">
                        <?php if ($p['status'] === 'Menunggu'): ?>
                            <span class="badge bg-warning text-dark">Menunggu</span>
                        <?php elseif ($p['status'] === 'Dikirim'): ?>
                            <span class="badge bg-info text-dark">Dikirim</span>
                        <?php else: ?>
                            <span class="badge bg-success">Selesai</span>
                        <?php endif; ?>
                    </td>

                    <!-- AKSI -->
                    <td class="text-center" style="min-width:160px">

                        <?php if ($p['status'] !== 'Selesai'): ?>
                            <form method="POST"
                                  action="<?= BASE_URL ?>/admin/updateStatus/<?= $p['id'] ?>">
                                
                                <select name="status" class="form-select form-select-sm mb-2">
                                    <option value="Menunggu" <?= $p['status']=='Menunggu'?'selected':'' ?>>
                                        Menunggu
                                    </option>
                                    <option value="Dikirim" <?= $p['status']=='Dikirim'?'selected':'' ?>>
                                        Dikirim
                                    </option>
                                    <option value="Selesai">
                                        Selesai
                                    </option>
                                </select>

                                <button class="btn btn-sm btn-success w-100">
                                    Update
                                </button>
                            </form>
                        <?php else: ?>
                            <span class="text-success fs-4">✔</span>
                        <?php endif; ?>

                    </td>
                </tr>
            <?php endforeach; ?>
        <?php else: ?>
            <tr>
                <td colspan="7" class="text-center text-muted">
                    Belum ada pesanan
                </td>
            </tr>
        <?php endif; ?>

        </tbody>
    </table>
</div>

<?php require "../app/views/layout/footer.php"; ?>
