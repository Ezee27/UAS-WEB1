<?php require "../app/views/layout/header.php"; ?>

<h3 class="fw-bold mb-4 text-center text-dark">📊 Data Pembelian</h3>

<!-- DATA PEMBELIAN -->
<div class="card border-0 shadow-sm mb-4">
    <div class="card-body">

        <!-- Pencarian -->
        <div class="mb-3">
            <input type="text"
                   class="form-control form-control-lg"
                   placeholder="Cari Pembelian..."
                   id="searchInput">
        </div>

        <!-- Table -->
        <div id="pembelianTableWrapper" style="max-height: 500px; overflow-y: auto;">
            <table class="table table-bordered table-striped align-middle">
                <thead class="table-light text-center">
                    <tr>
                        <th>ID</th>
                        <th>User</th>
                        <th>Burung</th>
                        <th>Jumlah</th>
                        <th>Total</th>
                        <th>Alamat</th>
                        <th>Status</th>
                        <th>Aksi</th>
                    </tr>
                </thead>

                <tbody id="pembelianTable">
                <?php if (mysqli_num_rows($transaksi) > 0): ?>
                    <?php while ($t = $transaksi->fetch_assoc()): ?>
                    <tr class="text-center">
                        <td><?= $t['id'] ?></td>
                        <td><?= $t['username'] ?></td>
                        <td><?= $t['nama_burung'] ?></td>
                        <td><?= $t['jumlah'] ?></td>
                        <td>Rp <?= number_format($t['total']) ?></td>
                        <td><?= $t['alamat'] ?></td>

                        <!-- STATUS -->
                        <td>
                            <?php if ($t['status'] === 'Selesai'): ?>
                                <span class="badge bg-success">✔ Selesai</span>
                            <?php elseif ($t['status'] === 'Dikirim'): ?>
                                <span class="badge bg-warning text-dark">🚚 Dikirim</span>
                            <?php else: ?>
                                <span class="badge bg-secondary">⏳ Menunggu</span>
                            <?php endif; ?>
                        </td>

                        <!-- AKSI -->
                        <td>
                            <?php if ($t['status'] !== 'Selesai'): ?>
                                <form method="POST"
                                      action="<?= BASE_URL ?>/admin/updateStatus/<?= $t['id'] ?>">
                                    <select name="status"
                                            class="form-select form-select-sm mb-2">
                                        <option value="Menunggu" <?= $t['status']=='Menunggu'?'selected':'' ?>>
                                            Menunggu
                                        </option>
                                        <option value="Dikirim" <?= $t['status']=='Dikirim'?'selected':'' ?>>
                                            Dikirim
                                        </option>
                                        <option value="Selesai">
                                            Selesai
                                        </option>
                                    </select>
                                    <button class="btn btn-sm btn-primary w-100">
                                        Update
                                    </button>
                                </form>
                            <?php else: ?>
                                <span class="text-success fs-4">✔</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="8" class="text-center text-muted">
                            Belum ada transaksi
                        </td>
                    </tr>
                <?php endif; ?>
                </tbody>

            </table>
        </div>
    </div>
</div>

<style>
    body {
        background-color: #f8f9fa;
    }

    .table-striped tbody tr:hover {
        background-color: #e9f7fc;
    }

    #pembelianTableWrapper {
        max-height: 400px;
        overflow-y: auto;
    }
</style>

<script>
document.getElementById('searchInput').addEventListener('input', function () {
    const filter = this.value.toLowerCase();
    const rows = document.querySelectorAll('#pembelianTable tr');

    rows.forEach(row => {
        const cols = row.querySelectorAll('td');
        let show = false;

        cols.forEach(col => {
            if (col.textContent.toLowerCase().includes(filter)) {
                show = true;
            }
        });

        row.style.display = show ? '' : 'none';
    });
});
</script>

<?php require "../app/views/layout/footer.php"; ?>
