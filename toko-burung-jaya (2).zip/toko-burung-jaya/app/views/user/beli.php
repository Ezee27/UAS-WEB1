<?php require "../app/views/layout/header.php"; ?>

<h3>Pembayaran</h3>

<div class="card col-md-6 mx-auto">
    <div class="card-body">

        <p><b>Nama Burung:</b> <?= $burung['nama_burung'] ?></p>
        <p><b>Harga:</b> Rp <?= number_format($burung['harga']) ?></p>

        <form method="post" action="<?= BASE_URL ?>/user/bayar">
            <input type="hidden" name="burung_id" value="<?= $burung['id'] ?>">

            <div class="mb-3">
                <label>Metode Pembayaran</label>
                <select name="metode_pembayaran" class="form-control" required>
                    <option value="Transfer Bank">Transfer Bank</option>
                    <option value="COD">COD</option>
                    <option value="E-Wallet">E-Wallet</option>
                </select>
            </div>

            <div class="mb-3">
                <label>Jumlah</label>
                <input type="number" name="jumlah"
                       class="form-control"
                       min="1"
                       max="<?= $burung['stok'] ?>"
                       value="1"
                       required>
            </div>

            <div class="mb-3">
                <label>Alamat Pengiriman</label>
                <textarea name="alamat" class="form-control" required></textarea>
            </div>

            <button class="btn btn-success w-100">Bayar</button>
        </form>
    </div>
</div>

<?php require "../app/views/layout/footer.php"; ?>
