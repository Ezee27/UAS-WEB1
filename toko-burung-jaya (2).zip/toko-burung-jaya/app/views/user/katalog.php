<?php require "../app/views/layout/header.php"; ?>

<h3 class="fw-bold text-center text-primary mb-5">🐦 Katalog Burung</h3>

<div class="row g-4">

<?php if (!empty($burung)): ?>
<?php foreach ($burung as $b): ?>
    <div class="col-6 col-md-4 col-lg-3">
        <div class="card shadow border-0 h-100">

            <!-- GAMBAR (INI FIX) -->
            <?php if (!empty($b['gambar'])): ?>
                <img
                    src="<?= BASE_URL ?>/public/uploads/burung/<?= htmlspecialchars($b['gambar']) ?>"
                    class="card-img-top"
                    style="height:180px; object-fit:cover;"
                    alt="<?= htmlspecialchars($b['nama_burung']) ?>"
                >
            <?php else: ?>
                <div class="d-flex align-items-center justify-content-center bg-light"
                     style="height:180px;">
                    <span class="text-muted">Tidak ada gambar</span>
                </div>
            <?php endif; ?>

            <div class="card-body d-flex flex-column">
                <h5 class="fw-bold"><?= htmlspecialchars($b['nama_burung']) ?></h5>

                <span class="badge bg-info mb-2 align-self-start">
                    <?= htmlspecialchars($b['jenis']) ?>
                </span>

                <h6 class="text-success fw-bold">
                    Rp <?= number_format($b['harga'], 0, ',', '.') ?>
                </h6>

                <small class="text-muted mb-2">
                    Stok: <?= (int)$b['stok'] ?>
                </small>

                <p class="text-muted flex-grow-1">
                    <?= htmlspecialchars($b['deskripsi']) ?>
                </p>

                <?php if ($b['stok'] > 0): ?>
                    <a href="<?= BASE_URL ?>/user/beli/<?= $b['id'] ?>"
                       class="btn btn-success w-100 rounded-pill">
                        Beli
                    </a>
                <?php else: ?>
                    <button class="btn btn-secondary w-100 rounded-pill" disabled>
                        Stok Habis
                    </button>
                <?php endif; ?>
            </div>

        </div>
    </div>
<?php endforeach; ?>
<?php else: ?>
    <div class="col-12 text-center text-muted">
        Data burung belum tersedia
    </div>
<?php endif; ?>

</div>

<?php require "../app/views/layout/footer.php"; ?>
