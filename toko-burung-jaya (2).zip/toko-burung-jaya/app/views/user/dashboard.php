<?php require "../app/views/layout/header.php"; ?>

<!-- HERO SECTION -->
<div class="mb-4">
    <h3 class="fw-bold text-primary">
        👋 Selamat Datang, <?= $_SESSION['user']['username'] ?>!
    </h3>
    <p class="text-muted">
        Selamat berbelanja di <b>Toko Burung Jaya</b> 🐦.
        Nikmati berbelanja burung pilihan dengan mudah dan cepat.
    </p>
</div>

<!-- MENU UTAMA -->
<div class="row g-4 mb-4">

    <!-- KATALOG -->
    <div class="col-md-3">
        <div class="card dashboard-card shadow-lg border-0 text-center">
            <div class="card-body p-4">
                <h6 class="text-muted mb-2">Katalog Burung</h6>
                <h4 class="fw-bold text-success">🐦 Katalog</h4>
                <a href="<?= BASE_URL ?>/user/katalog"
                   class="btn btn-success btn-lg mt-3 w-100 rounded-pill">
                    Lihat Katalog
                </a>
            </div>
        </div>
    </div>

    <!-- PEMESANAN -->
    <div class="col-md-3">
        <div class="card dashboard-card shadow-lg border-0 text-center">
            <div class="card-body p-4">
                <h6 class="text-muted mb-2">Pemesanan</h6>
                <h4 class="fw-bold text-warning">📦 Pesanan</h4>
                <a href="<?= BASE_URL ?>/user/pemesanan"
                   class="btn btn-warning btn-lg mt-3 w-100 rounded-pill text-white">
                    Lihat Pesanan
                </a>
            </div>
        </div>
    </div>

    <!-- HISTORY -->
    <div class="col-md-3">
        <div class="card dashboard-card shadow-lg border-0 text-center">
            <div class="card-body p-4">
                <h6 class="text-muted mb-2">Riwayat Pembelian</h6>
                <h4 class="fw-bold text-primary">🧾 History</h4>
                <a href="<?= BASE_URL ?>/user/history"
                   class="btn btn-primary btn-lg mt-3 w-100 rounded-pill">
                    Lihat History
                </a>
            </div>
        </div>
    </div>

    <!-- STATUS AKUN -->
    <div class="col-md-3">
        <div class="card dashboard-card shadow-lg border-0 h-100">
            <div class="card-body p-4">
                <h6 class="text-muted mb-2">Status Akun</h6>
                <h4 class="fw-bold text-dark">✅ Aktif</h4>
                <small class="text-muted">
                    <i class="bi bi-person-circle"></i>
                    Role: <?= $_SESSION['user']['role'] ?>
                </small>
            </div>
        </div>
    </div>

</div>

<!-- STATISTIK RINGKAS -->
<div class="row g-4">

    <!-- TOTAL PEMBELIAN -->
    <div class="col-md-6">
        <div class="card dashboard-card shadow-lg border-0 h-100">
            <div class="card-body p-4">
                <h6 class="text-muted mb-2">Total Pembelian</h6>

                <a href="<?= BASE_URL ?>/user/history" class="text-decoration-none">
                    <h4 class="fw-bold text-success">
                        💰 Rp <?= number_format($totalPembelian ?? 0, 0, ',', '.') ?>
                    </h4>
                </a>

                <p class="text-muted">
                    Total dari <?= $jumlahTransaksi ?? 0 ?> transaksi Anda.
                </p>
            </div>
        </div>
    </div>


</div>

<?php require "../app/views/layout/footer.php"; ?>

<!-- STYLE -->
<style>
    body {
        background-color: #f4f7fc;
    }

    .dashboard-card {
        border-radius: 1.5rem;
        background: linear-gradient(145deg, #ffffff, #f0f1f6);
        transition: transform 0.3s ease, box-shadow 0.3s ease;
    }

    .dashboard-card:hover {
        transform: translateY(-6px);
        box-shadow: 0px 10px 20px rgba(0, 0, 0, 0.12);
    }

    .btn-lg {
        padding: 14px;
        font-size: 1.1rem;
    }
</style>

<!-- ICON -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css">
