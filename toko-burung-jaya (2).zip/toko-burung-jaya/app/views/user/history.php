<?php require "../app/views/layout/header.php"; ?>

<h3 class="fw-bold mb-4 text-center">🧾 Riwayat Pembelian</h3>

<?php if (!empty($transaksi) && $transaksi->num_rows > 0): ?>
    <div class="table-responsive">
        <table class="table table-bordered table-hover align-middle">
            <thead class="table-dark text-center">
                <tr>
                    <th>No</th>
                    <th>Nama Burung</th>
                    <th>Jumlah</th>
                    <th>Total</th>
                    <th>Metode Pembayaran</th>
                    <th>Tanggal</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php $no = 1; while ($t = $transaksi->fetch_assoc()): ?>
                    <tr>
                        <td class="text-center"><?= $no++ ?></td>
                        <td><?= htmlspecialchars($t['nama_burung']) ?></td>
                        <td class="text-center"><?= $t['jumlah'] ?></td>
                        <td>Rp <?= number_format($t['total']) ?></td>
                        <td><?= htmlspecialchars($t['metode_pembayaran']) ?></td>
                        <td class="text-center">
                            <?= isset($t['created_at']) 
                                ? date('d-m-Y H:i', strtotime($t['created_at'])) 
                                : '-' ?>
                        </td>
                        <td class="text-center">
                            <?php if ($t['status'] === 'Selesai'): ?>
                                <span class="badge bg-success">Selesai</span>
                            <?php elseif ($t['status'] === 'Dikirim'): ?>
                                <span class="badge bg-primary">Dikirim</span>
                            <?php else: ?>
                                <span class="badge bg-warning text-dark">Menunggu</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
<?php else: ?>
    <div class="alert alert-info text-center">
        Belum ada transaksi.
    </div>
<?php endif; ?>

<?php require "../app/views/layout/footer.php"; ?>
