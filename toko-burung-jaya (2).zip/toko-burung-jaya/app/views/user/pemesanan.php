<?php require "../app/views/layout/header.php"; ?>

<h3 class="fw-bold mb-4">📦 Pemesanan Saya</h3>

<?php foreach ($pesanan as $p): ?>

<?php
// SIMULASI STATUS OTOMATIS (30 DETIK)
$waktu = strtotime($p['created_at']);
$sekarang = time();
$selisih = $sekarang - $waktu;

$status = $p['status'];

if ($selisih > 10) $status = 'Diterima Admin';
if ($selisih > 20) $status = 'Dalam Perjalanan';
if ($selisih > 30) $status = 'Pesanan Tiba';
?>

<div class="card mb-3 shadow-sm">
    <div class="card-body">
        <h5 class="fw-bold"><?= $p['nama_burung'] ?></h5>
        <p class="mb-1">Jumlah: <?= $p['jumlah'] ?></p>
        <p class="mb-1">Total: Rp <?= number_format($p['total']) ?></p>
        <p class="mb-1"><b>Alamat:</b> <?= $p['alamat'] ?></p>

        <span class="badge 
            <?= $status == 'Pesanan Tiba' ? 'bg-success' : 'bg-warning' ?>">
            <?= $status ?>
        </span>

        <?php if ($status != 'Pesanan Tiba'): ?>
            <p class="text-muted mt-2">
                ⏳ Estimasi tiba: <?= max(0, 30 - $selisih) ?> detik
            </p>
        <?php else: ?>
            <p class="text-success mt-2">✅ Pesanan telah sampai</p>
        <?php endif; ?>
    </div>
</div>

<?php endforeach; ?>

<?php require "../app/views/layout/footer.php"; ?>
