<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Toko Burung Jaya</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body class="d-flex flex-column min-vh-100">

<nav class="navbar navbar-dark bg-success">
    <div class="container-fluid px-4">

        <?php if (isset($_SESSION['user'])): ?>
            <a class="navbar-brand fw-bold"
               href="<?= BASE_URL ?>/<?= $_SESSION['user']['role'] ?>/dashboard">
                Toko Burung Jaya
            </a>
        <?php else: ?>
            <a class="navbar-brand fw-bold" href="<?= BASE_URL ?>/auth">
                Toko Burung Jaya
            </a>
        <?php endif ?>

        <?php if (isset($_SESSION['user'])): ?>
            <a href="<?= BASE_URL ?>/auth/logout" class="btn btn-danger btn-sm">
                Logout
            </a>
        <?php endif ?>

    </div>
</nav>

<main class="flex-fill">
<div class="container py-4">
