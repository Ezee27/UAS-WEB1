    </div> <!-- end container -->
</main>

<footer class="bg-light text-center py-3 mt-auto border-top">
    <small>© 2026 - Toko Burung Jaya</small>
</footer>

</body>
</html>
