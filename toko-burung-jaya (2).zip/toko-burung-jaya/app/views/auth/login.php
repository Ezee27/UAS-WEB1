<?php require "../app/views/layout/header.php"; ?>

<div class="container d-flex justify-content-center align-items-center min-vh-100">
    <div class="col-md-6 col-lg-4">
        <div class="card shadow">
            <div class="card-body">
                <h4 class="text-center mb-3">Login</h4>

                <form method="POST" action="<?= BASE_URL ?>/auth/login">
                    <div class="mb-3">
                        <input type="text" name="username" class="form-control form-control-lg" placeholder="Username" required>
                    </div>

                    <div class="mb-3">
                        <input type="password" name="password" class="form-control form-control-lg" placeholder="Password" required>
                    </div>

                    <button class="btn btn-success w-100 btn-lg">Login</button>
                </form>

            </div>
        </div>
    </div>
</div>

<?php require "../app/views/layout/footer.php"; ?>
