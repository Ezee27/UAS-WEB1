<?php
// app/controllers/BurungController.php

require_once __DIR__ . '/../models/Burung.php';

class BurungController extends Controller {

    public function index() {
        $burungModel = new Burung();
        $data['burung'] = $burungModel->getAll();
        $this->view('burung/index', $data);
    }

    // ===============================
    // TAMBAH BURUNG
    // ===============================
    public function tambah() {

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {

            $gambar = null;

            if (!empty($_FILES['gambar']['name'])) {
                $ext = pathinfo($_FILES['gambar']['name'], PATHINFO_EXTENSION);
                $gambar = uniqid('burung_') . '.' . $ext;

                $folder = __DIR__ . '/../../public/uploads/burung/';
                if (!is_dir($folder)) {
                    mkdir($folder, 0777, true);
                }

                move_uploaded_file(
                    $_FILES['gambar']['tmp_name'],
                    $folder . $gambar
                );
            }

            $burungModel = new Burung();
            $burungModel->insert([
                'nama_burung' => $_POST['nama_burung'],
                'jenis'       => $_POST['jenis'],
                'harga'       => $_POST['harga'],
                'stok'        => $_POST['stok'],
                'deskripsi'   => $_POST['deskripsi'],
                'gambar'      => $gambar
            ]);

            header("Location: " . BASE_URL . "/burung");
            exit;
        }

        $this->view('burung/tambah');
    }

    // ===============================
    // EDIT BURUNG
    // ===============================
    public function edit($id) {

        $burungModel = new Burung();
        $burung = $burungModel->getById($id);

        if ($_SERVER['REQUEST_METHOD'] === 'POST') {

            $gambar = $_POST['gambar_lama'];

            if (!empty($_FILES['gambar']['name'])) {
                $ext = pathinfo($_FILES['gambar']['name'], PATHINFO_EXTENSION);
                $gambar = uniqid('burung_') . '.' . $ext;

                $folder = __DIR__ . '/../../public/uploads/burung/';
                move_uploaded_file(
                    $_FILES['gambar']['tmp_name'],
                    $folder . $gambar
                );

                if (!empty($_POST['gambar_lama'])) {
                    @unlink($folder . $_POST['gambar_lama']);
                }
            }

            $burungModel->update($id, [
                'nama_burung' => $_POST['nama_burung'],
                'jenis'       => $_POST['jenis'],
                'harga'       => $_POST['harga'],
                'stok'        => $_POST['stok'],
                'deskripsi'   => $_POST['deskripsi'],
                'gambar'      => $gambar
            ]);

            header("Location: " . BASE_URL . "/burung");
            exit;
        }

        $data['burung'] = $burung;
        $this->view('burung/edit', $data);
    }

    public function hapus($id) {
        $burungModel = new Burung();
        $burungModel->delete($id);
        header("Location: " . BASE_URL . "/burung");
        exit;
    }
}
