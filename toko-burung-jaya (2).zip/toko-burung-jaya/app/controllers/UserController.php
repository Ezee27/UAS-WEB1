<?php

require_once __DIR__ . '/../models/Burung.php';
require_once __DIR__ . '/../models/Transaksi.php';

class UserController extends Controller {

    // ===============================
    // VALIDASI USER LOGIN
    // ===============================
    private function checkUser() {
        if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'user') {
            header("Location: " . BASE_URL . "/auth");
            exit;
        }
    }

    // ===============================
    // DASHBOARD
    // ===============================
    public function dashboard() {
        $this->checkUser();

        $transaksiModel = new Transaksi();
        $userId = $_SESSION['user']['id'];

        $data['totalPembelian'] = $transaksiModel->totalPembelianByUser($userId);
        $data['jumlahTransaksi'] = $transaksiModel->countByUser($userId);

        $this->view('user/dashboard', $data);
    }

    // ===============================
    // KATALOG
    // ===============================
    public function katalog() {
        $this->checkUser();

        $burungModel = new Burung();
        $data['burung'] = $burungModel->getAll();

        $this->view('user/katalog', $data);
    }

    // ===============================
    // HALAMAN BELI
    // ===============================
    public function beli($id) {
        $this->checkUser();

        $burungModel = new Burung();
        $burung = $burungModel->getById((int)$id);

        if (!$burung) {
            header("Location: " . BASE_URL . "/user/katalog");
            exit;
        }

        $this->view('user/beli', ['burung' => $burung]);
    }

    // ===============================
    // PROSES BAYAR
    // ===============================
    public function bayar() {
        $this->checkUser();

        $burung_id = (int)($_POST['burung_id'] ?? 0);
        $jumlah    = (int)($_POST['jumlah'] ?? 0);
        $metode    = $_POST['metode_pembayaran'] ?? '';
        $alamat    = trim($_POST['alamat'] ?? '');

        if ($burung_id <= 0 || $jumlah <= 0 || empty($alamat)) {
            die("Data tidak valid");
        }

        $burungModel = new Burung();
        $burung = $burungModel->getById($burung_id);

        if (!$burung) {
            die("Burung tidak ditemukan");
        }

        if ($jumlah > $burung['stok']) {
            die("Stok tidak mencukupi");
        }

        $total = $burung['harga'] * $jumlah;

        $transaksiModel = new Transaksi();
        $transaksiModel->insert([
            'user_id' => $_SESSION['user']['id'],
            'burung_id' => $burung_id,
            'jumlah' => $jumlah,
            'total' => $total,
            'metode_pembayaran' => $metode,
            'alamat' => $alamat
        ]);

        $burungModel->kurangiStok($burung_id, $jumlah);

        header("Location: " . BASE_URL . "/user/pemesanan");
        exit;
    }

    // ===============================
    // PEMESANAN
    // ===============================
    public function pemesanan() {
        $this->checkUser();

        $transaksiModel = new Transaksi();
        $data['pesanan'] = $transaksiModel->getByUser($_SESSION['user']['id']);

        $this->view('user/pemesanan', $data);
    }

    // ===============================
    // HISTORY
    // ===============================
    public function history() {
        $this->checkUser();

        $transaksiModel = new Transaksi();
        $data['transaksi'] = $transaksiModel->getByUser($_SESSION['user']['id']);

        $this->view('user/history', $data);
    }
}
