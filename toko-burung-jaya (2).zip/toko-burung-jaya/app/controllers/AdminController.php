<?php
// app/controllers/AdminController.php

require_once __DIR__ . '/../models/Burung.php';
require_once __DIR__ . '/../models/Transaksi.php';
require_once __DIR__ . '/../models/User.php';

class AdminController extends Controller {

    // ===============================
    // CEK ADMIN
    // ===============================
    private function checkAdmin() {
        if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
            header("Location: " . BASE_URL . "/auth");
            exit;
        }
    }

    // ===============================
    // DASHBOARD ADMIN
    // ===============================
    public function dashboard() {
        $this->checkAdmin();

        $transaksiModel = new Transaksi();
        $userModel      = new User();
        $burungModel    = new Burung();

        $data = [
            'totalTransaksi' => $transaksiModel->count(),
            'totalBurung'    => $burungModel->count(),
            'totalUser'      => $userModel->count(),
            'totalPembelian' => $transaksiModel->totalPembelian(),
            'transaksi'      => $transaksiModel->getAll(),
            'users'          => $userModel->getAll()
        ];

        $this->view('admin/dashboard', $data);
    }

    // ===============================
    // PEMBELIAN (RIWAYAT)
    // ===============================
    public function pembelian() {
        $this->checkAdmin();

        $transaksiModel = new Transaksi();

        $data = [
            'transaksi'      => $transaksiModel->getAll(),
            'totalPembelian' => $transaksiModel->totalPembelian()
        ];

        $this->view('admin/pembelian', $data);
    }

    // ===============================
    // PEMESANAN (MENUNGGU / DIKIRIM / SELESAI)
    // ===============================
    public function pemesanan() {
        $this->checkAdmin();

        $transaksiModel = new Transaksi();

        $data['pesanan'] = $transaksiModel->getAll();

        $this->view('admin/pemesanan', $data);
    }

    // ===============================
    // UPDATE STATUS PESANAN
    // ===============================
    public function updateStatus($id) {
        $this->checkAdmin();

        if (!isset($_POST['status'])) {
            header("Location: " . BASE_URL . "/admin/pemesanan");
            exit;
        }

        // VALIDASI STATUS
        $allowedStatus = ['Menunggu', 'Dikirim', 'Selesai'];
        $status = $_POST['status'];

        if (!in_array($status, $allowedStatus)) {
            die("Status tidak valid");
        }

        $transaksiModel = new Transaksi();
        $transaksiModel->updateStatus((int)$id, $status);

        header("Location: " . BASE_URL . "/admin/pemesanan");
        exit;
    }

    // ===============================
    // DATA USER
    // ===============================
    public function user() {
        $this->checkAdmin();

        $userModel = new User();
        $data['users'] = $userModel->getAll();

        $this->view('admin/user', $data);
    }
}
