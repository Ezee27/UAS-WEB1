<?php

require_once __DIR__ . '/../models/User.php';

class AuthController extends Controller {

    public function index() {
        $this->view('auth/login');
    }

    public function login() {
        $user = (new User)->login(
            $_POST['username'],
            $_POST['password']
        );

        if ($user) {
            $_SESSION['user'] = $user;

            if ($user['role'] === 'admin') {
                header("Location: " . BASE_URL . "/admin/dashboard");
            } else {
                header("Location: " . BASE_URL . "/user/dashboard");
            }
            exit;
        }

        header("Location: " . BASE_URL . "/auth");
        exit;
    }

    public function logout() {
        session_destroy();
        header("Location: " . BASE_URL . "/auth");
        exit;
    }
}
