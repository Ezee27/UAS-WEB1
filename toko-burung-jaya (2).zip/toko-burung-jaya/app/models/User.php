<?php

class User extends Database {

    public function login($username, $password) {

        $username = mysqli_real_escape_string($this->conn, $username);

        $query = "SELECT * FROM users WHERE username='$username'";
        $result = $this->query($query);

        if ($result && $result->num_rows === 1) {
            $user = $result->fetch_assoc();

            // cocok untuk password plaintext (UAS friendly)
            if ($user['password'] === $password) {
                return $user;
            }
        }

        return false;
    }

    // 🔥 total user
    public function count() {
        $result = $this->query("SELECT COUNT(*) AS total FROM users");
        return $result->fetch_assoc()['total'];
    }

    // 🔥 data user
    public function getAll() {
        return $this->query("SELECT id, username, role FROM users");
    }
}
