<?php
// app/models/Transaksi.php

class Transaksi extends Database {

    // ===============================
    // TOTAL PEMBELIAN PER USER (DASHBOARD USER)
    // ===============================
    public function totalPembelianByUser($user_id) {
        $user_id = (int)$user_id;

        $result = $this->query(
            "SELECT SUM(total) AS total_pembelian 
             FROM transaksi 
             WHERE user_id = $user_id"
        );

        return $result->fetch_assoc()['total_pembelian'] ?? 0;
    }

    // ===============================
    // TOTAL PEMBELIAN (ADMIN DASHBOARD) ✅ FIX UTAMA
    // ===============================
    public function totalPembelian() {
        $result = $this->query(
            "SELECT SUM(total) AS total_pembelian FROM transaksi"
        );

        return $result->fetch_assoc()['total_pembelian'] ?? 0;
    }

    // ===============================
    // JUMLAH TRANSAKSI PER USER
    // ===============================
    public function countByUser($user_id) {
        $user_id = (int)$user_id;

        $result = $this->query(
            "SELECT COUNT(*) AS total 
             FROM transaksi 
             WHERE user_id = $user_id"
        );

        return $result->fetch_assoc()['total'] ?? 0;
    }

    // ===============================
    // JUMLAH TRANSAKSI (ADMIN DASHBOARD)
    // ===============================
    public function count() {
        $result = $this->query(
            "SELECT COUNT(*) AS total FROM transaksi"
        );

        return $result->fetch_assoc()['total'] ?? 0;
    }

    // ===============================
    // TRANSAKSI USER (PEMESANAN + HISTORY)
    // ===============================
    public function getByUser($user_id) {
        $query = "SELECT 
                    t.id,
                    b.nama_burung,
                    t.jumlah,
                    t.total,
                    t.metode_pembayaran,
                    t.alamat,
                    t.status,
                    t.created_at
                FROM transaksi t
                JOIN burung b ON t.burung_id = b.id
                WHERE t.user_id = ?
                ORDER BY t.created_at DESC";

        $stmt = $this->prepare($query);
        $stmt->bind_param("i", $user_id);
        $stmt->execute();

        return $stmt->get_result();
    }

    // ===============================
    // PAGINATION ADMIN
    // ===============================
    public function getPembelianPaginated($currentPage, $itemsPerPage) {
        $offset = ($currentPage - 1) * $itemsPerPage;

        $query = "SELECT 
                    t.id,
                    u.username,
                    b.nama_burung,
                    t.jumlah,
                    t.total,
                    t.metode_pembayaran,
                    t.status,
                    t.created_at
                FROM transaksi t
                JOIN users u ON t.user_id = u.id
                JOIN burung b ON t.burung_id = b.id
                ORDER BY t.created_at DESC
                LIMIT $offset, $itemsPerPage";

        return $this->query($query);
    }

    // ===============================
    // INSERT TRANSAKSI (BAYAR)
    // ===============================
    public function insert($data) {
        $user_id   = (int)$data['user_id'];
        $burung_id = (int)$data['burung_id'];
        $jumlah    = (int)$data['jumlah'];
        $total     = (int)$data['total'];

        $metode = $this->escape($data['metode_pembayaran']);
        $alamat = $this->escape($data['alamat']);

        $sql = "INSERT INTO transaksi 
                (user_id, burung_id, jumlah, total, metode_pembayaran, alamat, status, created_at)
                VALUES (
                    $user_id,
                    $burung_id,
                    $jumlah,
                    $total,
                    '$metode',
                    '$alamat',
                    'Menunggu',
                    NOW()
                )";

        return $this->query($sql);
    }

    // ===============================
    // SEMUA TRANSAKSI (ADMIN)
    // ===============================
    public function getAll() {
        return $this->query("SELECT 
                t.id,
                u.username,
                b.nama_burung,
                t.jumlah,
                t.total,
                t.metode_pembayaran,
                t.alamat,
                t.status,
                t.created_at
            FROM transaksi t
            JOIN users u ON t.user_id = u.id
            JOIN burung b ON t.burung_id = b.id
            ORDER BY t.created_at DESC");
    }

    // ===============================
    // UPDATE STATUS (ADMIN)
    // ===============================
    public function updateStatus($id, $status) {
        $id = (int)$id;
        $status = $this->escape($status);

        return $this->query(
            "UPDATE transaksi SET status='$status' WHERE id=$id"
        );
    }
}
