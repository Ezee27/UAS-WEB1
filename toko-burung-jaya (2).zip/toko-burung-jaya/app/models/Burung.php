<?php

class Burung {
    private $db;

    public function __construct() {
        $this->db = new Database();
    }

    // ===============================
    // Ambil semua data burung
    // ===============================
    public function getAll() {
        $result = $this->db->query("SELECT * FROM burung ORDER BY id DESC");
        $data = [];

        if ($result) {
            while ($row = $result->fetch_assoc()) {
                $data[] = $row;
            }
        }

        return $data;
    }

    // ===============================
    // Ambil burung berdasarkan ID
    // ===============================
    public function getById($id) {
        $id = (int)$id;
        $result = $this->db->query("SELECT * FROM burung WHERE id = $id");
        return $result ? $result->fetch_assoc() : null;
    }

    // ===============================
    // Tambah burung
    // ===============================
    public function insert($data) {
        $nama_burung = $this->db->escape($data['nama_burung']);
        $jenis       = $this->db->escape($data['jenis']);
        $harga       = (int)$data['harga'];
        $stok        = (int)$data['stok'];
        $deskripsi   = $this->db->escape($data['deskripsi']);
        $gambar      = isset($data['gambar']) ? $this->db->escape($data['gambar']) : null;

        $sql = "
            INSERT INTO burung 
            (nama_burung, jenis, harga, stok, deskripsi, gambar)
            VALUES
            (
                '$nama_burung',
                '$jenis',
                $harga,
                $stok,
                '$deskripsi',
                " . ($gambar ? "'$gambar'" : "NULL") . "
            )
        ";

        return $this->db->query($sql);
    }

    // ===============================
    // Update burung (gambar optional)
    // ===============================
    public function update($id, $data) {
        $id          = (int)$id;
        $nama_burung = $this->db->escape($data['nama_burung']);
        $jenis       = $this->db->escape($data['jenis']);
        $harga       = (int)$data['harga'];
        $stok        = (int)$data['stok'];
        $deskripsi   = $this->db->escape($data['deskripsi']);

        $sql = "
            UPDATE burung SET
                nama_burung = '$nama_burung',
                jenis = '$jenis',
                harga = $harga,
                stok = $stok,
                deskripsi = '$deskripsi'
        ";

        // kalau ada gambar baru
        if (!empty($data['gambar'])) {
            $gambar = $this->db->escape($data['gambar']);
            $sql .= ", gambar = '$gambar'";
        }

        $sql .= " WHERE id = $id";

        return $this->db->query($sql);
    }

    // ===============================
    // Kurangi stok saat pembelian
    // ===============================
    public function kurangiStok($id, $jumlah = 1) {
        $id = (int)$id;
        $jumlah = (int)$jumlah;

        $sql = "
            UPDATE burung 
            SET stok = stok - $jumlah
            WHERE id = $id AND stok >= $jumlah
        ";

        return $this->db->query($sql);
    }

    // ===============================
    // Hapus burung
    // ===============================
    public function delete($id) {
        $id = (int)$id;
        return $this->db->query("DELETE FROM burung WHERE id = $id");
    }

    // ===============================
    // Hitung jumlah burung
    // ===============================
    public function count() {
        $result = $this->db->query("SELECT COUNT(*) AS total FROM burung");
        $row = $result->fetch_assoc();
        return $row['total'];
    }
}
