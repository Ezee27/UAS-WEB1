CREATE TABLE users (
 id INT AUTO_INCREMENT PRIMARY KEY,
 username VARCHAR(50),
 password VARCHAR(50),
 role ENUM('admin','user')
);

CREATE TABLE burung (
 id INT AUTO_INCREMENT PRIMARY KEY,
 nama_burung VARCHAR(100),
 jenis VARCHAR(100),
 harga INT,
 stok INT
);
