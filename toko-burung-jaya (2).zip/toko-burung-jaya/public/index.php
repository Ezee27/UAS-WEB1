<?php
session_start();

// Mendefinisikan BASE_URL yang sesuai dengan aplikasi Anda
define('BASE_URL', 'http://localhost/toko-burung-jaya');  // Sesuaikan dengan URL yang sesuai dengan aplikasi Anda

require_once __DIR__ . '/../core/Database.php';
require_once __DIR__ . '/../core/Controller.php';
require_once __DIR__ . '/../core/Router.php';
